from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION

OUT = r'C:\Users\panda\Documents\Codex\2026-09-27\LLM-PYTHON\outputs\parallel-multi-llm\Multi_LLM_Chat_Technical_Project_Report.docx'
doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(.72); sec.bottom_margin = Inches(.72)
sec.left_margin = Inches(.82); sec.right_margin = Inches(.82)
sec.header_distance = Inches(.32); sec.footer_distance = Inches(.35)

NAVY = '17233B'; BLUE = '3859A6'; TEAL = '168A83'; PALE = 'EEF3FA'; LIGHT = 'F4F6F9'; MID = '667085'; WHITE='FFFFFF'; AMBER='A35A13'
styles = doc.styles
normal = styles['Normal']; normal.font.name='Aptos'; normal.font.size=Pt(9.4); normal.font.color.rgb=RGBColor.from_string('293246')
normal.paragraph_format.space_after=Pt(5); normal.paragraph_format.line_spacing=1.12
for name, size, color in [('Title',31,NAVY),('Heading 1',18,NAVY),('Heading 2',12,BLUE),('Heading 3',10,TEAL)]:
    s=styles[name]; s.font.name='Aptos Display'; s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor.from_string(color)
    s.paragraph_format.space_before=Pt(12 if name!='Title' else 0); s.paragraph_format.space_after=Pt(5)

def shade(cell, fill):
    pr=cell._tc.get_or_add_tcPr(); sh=OxmlElement('w:shd'); sh.set(qn('w:fill'),fill); pr.append(sh)
def set_cell_text(cell, text, bold=False, color=None, size=8.5):
    cell.text=''; p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(1); p.paragraph_format.space_before=Pt(1)
    r=p.add_run(text); r.bold=bold; r.font.name='Aptos'; r.font.size=Pt(size)
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def table(headers, rows, widths=None):
    t=doc.add_table(rows=1, cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    if widths:
        for c,w in zip(t.columns,widths): c.width= Inches(w)
    for c,h in zip(t.rows[0].cells,headers): shade(c,NAVY); set_cell_text(c,h,True,WHITE,8.2)
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        if widths:
            for c,w in zip(cells,widths): c.width= Inches(w)
        for c,txt in zip(cells,row):
            shade(c, 'FFFFFF' if ri%2==0 else LIGHT); set_cell_text(c,str(txt),size=8.1)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t
def para(text='', style=None, bold_lead=None):
    p=doc.add_paragraph(style=style)
    if bold_lead and text.startswith(bold_lead):
        p.add_run(bold_lead).bold=True; p.add_run(text[len(bold_lead):])
    else: p.add_run(text)
    return p
def bullet(text):
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(2); p.add_run(text); return p
def numbered(text):
    p=doc.add_paragraph(style='List Number'); p.paragraph_format.space_after=Pt(2); p.add_run(text); return p
def callout(label, text, fill=PALE):
    t=doc.add_table(rows=1,cols=1); t.alignment=WD_TABLE_ALIGNMENT.CENTER
    c=t.cell(0,0); shade(c,fill); c.text=''; p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(3)
    r=p.add_run(label+'  '); r.bold=True; r.font.color.rgb=RGBColor.from_string(BLUE)
    p.add_run(text)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
def page_field(p):
    p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    r=p.add_run('PARALLEL  •  TECHNICAL PROJECT REPORT     |     '); r.font.size=Pt(7.5); r.font.color.rgb=RGBColor.from_string(MID)
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); p._p.append(fld)

# Running header/footer
hp=sec.header.paragraphs[0]; hp.text='PARALLEL  /  MULTI-LLM CHAT'; hp.style='Caption'
hp.runs[0].font.bold=True; hp.runs[0].font.size=Pt(8); hp.runs[0].font.color.rgb=RGBColor.from_string(TEAL)
page_field(sec.footer.paragraphs[0])

# Cover
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(54); p.paragraph_format.space_after=Pt(11)
r=p.add_run('SOFTWARE ENGINEERING  /  PROJECT REPORT'); r.bold=True; r.font.size=Pt(9); r.font.color.rgb=RGBColor.from_string(TEAL)
p=doc.add_paragraph(style='Title'); p.add_run('Multi-LLM Chat\nComparison Application')
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(9)
r=p.add_run('Technical design, implementation review, and enhancement roadmap'); r.font.size=Pt(15); r.font.color.rgb=RGBColor.from_string(MID)
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(23)
r=p.add_run('A Python and Streamlit application for sending one prompt to multiple model providers and reviewing their responses in parallel.'); r.font.size=Pt(11)
doc.add_paragraph('\n')
table(['PROJECT PROFILE','DETAIL'],[
('Application name','Parallel — Multi-LLM Chat'),('Technology','Python 3.10+, Streamlit, Requests'),('Interaction model','Single prompt broadcast to selected providers; concurrent responses'),('Provider adapters','OpenAI, Anthropic, Google Gemini, Ollama, OpenAI-compatible APIs'),('Report basis','Generated application source, README, and dependency manifest'),('Assessment scope','Architecture and source-level review; no runtime or provider calls performed')],[1.65,5.45])
doc.add_paragraph('\n')
callout('EXECUTIVE SUMMARY','The app is a compact local prototype for comparing independent model outputs. Its strongest design choice is provider fan-out through a shared result shape, which keeps the user workflow simple while allowing provider-specific HTTP adapters. The next engineering step is to harden instruction handling, API configuration, failure controls, and operational security before exposing it to multiple users or deploying it publicly.')
doc.add_page_break()

doc.add_heading('1. Executive overview',level=1)
para('Parallel addresses a practical evaluation task: ask several language models the same question, then compare their answers in one screen. A Streamlit interface collects provider choices and prompt text; a thread pool issues independent HTTP requests concurrently; each answer is displayed in its own panel with its model name and elapsed time.')
para('The current project is best understood as a local, single-user comparison prototype. It has no application database, user accounts, server-side job queue, persistent conversation store, or automatic answer judging. The README describes prompt history as session-scoped, and the source keeps it in Streamlit session state.')
doc.add_heading('Key outcomes',level=2)
bullet('One prompt can be sent to multiple selected providers from a single interaction.')
bullet('Provider requests run concurrently, reducing total wait time versus sequential calls when providers respond independently.')
bullet('Credentials are configurable through password fields, environment variables, or Streamlit secrets; Ollama can be used without a cloud key.')
bullet('Provider errors are converted to per-model results so one failed request does not inherently prevent other answers from being displayed.')
doc.add_heading('Scope and interpretation',level=2)
para('This report describes the delivered source implementation. Provider availability, model identifiers, endpoint behavior, package compatibility, visual rendering, and live response quality have not been verified by executing the application. Model defaults are editable in the interface and should be checked against current provider catalogs before use.')

doc.add_heading('2. Problem definition and objectives',level=1)
para('When model outputs are gathered in separate chat interfaces, comparison adds repeated prompt entry and makes differences harder to inspect. Parallel reduces that friction by presenting independent responses together while preserving the identity of each provider and model.')
table(['OBJECTIVE','IMPLEMENTATION IN THE APP'],[
('Reduce repeated input','One prompt field is submitted once for all selected providers.'),
('Enable side-by-side review','Responses appear in separate Streamlit columns with provider and model labels.'),
('Keep provider integration lightweight','Direct HTTP calls through Requests avoid provider SDK dependencies.'),
('Support local inference','Ollama adapter targets a configurable local server.'),
('Expose basic latency','Each result records elapsed wall-clock seconds.'),
('Keep workflow easy to run','README supplies a virtual-environment and Streamlit launch path.')],[2.0,5.1])

doc.add_heading('3. System architecture',level=1)
para('The system is a single-process Streamlit application. UI state, configuration, orchestration, provider HTTP requests, and response rendering live in app.py. The provider-specific function ask() translates a common input into an endpoint-specific request and returns a Result object with provider, model, text or error, and elapsed time.')
table(['LAYER','RESPONSIBILITY','CURRENT IMPLEMENTATION'],[
('Presentation','Provider selection, model/key fields, prompt capture, response cards','Streamlit sidebar, form, columns, session state'),
('Orchestration','Validate required inputs and dispatch model calls','Form validation; ThreadPoolExecutor'),
('Provider adapters','Map common prompt and system text to provider schemas','ask() branches by provider kind'),
('Transport','Send JSON requests and interpret HTTP errors','requests.post with timeout and JSON parsing'),
('Session state','Keep recent prompt/answer entries during session','st.session_state.history'),
('Configuration','Supply defaults and secrets','Constants, environment variables, Streamlit secrets, UI inputs')],[1.2,2.4,3.5])
doc.add_heading('Request lifecycle',level=2)
for s in ['The user selects providers and supplies model names and credentials or endpoint URLs.','The form validates that the prompt, selection, model names, and required credentials are present.','A ThreadPoolExecutor creates one task per selected provider; every task receives the same prompt and instruction string.','Each adapter submits one synchronous HTTP request and converts its response or exception into a Result.','Results are gathered and added to session history, then rendered in provider-labeled columns.']:
    numbered(s)
callout('CONCURRENCY MODEL','Concurrency is request-level and bounded by the number of providers selected in that submission. It improves wall-clock latency when requests overlap, but does not make provider responses comparable in quality or guarantee that all calls complete at the same time.')

doc.add_heading('4. Provider integration design',level=1)
table(['PROVIDER','API PATH / PROTOCOL','CONFIGURATION','RESPONSE EXTRACTION'],[
('OpenAI','Chat Completions; /v1/chat/completions','OPENAI_API_KEY; model in UI','choices[0].message.content'),
('Anthropic','Messages API; /v1/messages','ANTHROPIC_API_KEY; model in UI','Text blocks from content array'),
('Google Gemini','generateContent; model-specific REST path','GEMINI_API_KEY; model in UI','Candidate content parts'),
('Ollama','Local /api/chat','Base URL; model in UI','message.content'),
('OpenAI-compatible','Configurable chat completions endpoint','Base URL, API key, model in UI','OpenAI-style choices/message content')],[1.25,2.2,2.0,1.65])
para('The common adapter boundary is useful for this application because all providers receive a prompt and return displayable text. The trade-off is that provider-specific capabilities—tool calls, multimodal input, token usage, finish reasons, streaming, and structured output—are not represented in the common Result object.')
doc.add_heading('Provider-specific behavior to review',level=2)
bullet('The Gemini adapter sends a non-empty system instruction as an additional user-role content entry, then sends the prompt as a second user entry. This does not express a dedicated system instruction and may change model behavior. Use the provider’s system-instruction field where supported.')
bullet('The current provider defaults name specific models in source. Provider model availability changes; treat defaults as convenience values and validate them against current provider documentation.')
bullet('The OpenAI-compatible URL helper appends /chat/completions unless that suffix is already present. Endpoints with different path conventions need an explicit adapter or a clearer URL contract.')
bullet('The Ollama endpoint is local by default, but a user-provided base URL can point elsewhere. Treat that endpoint as trusted configuration.')

doc.add_heading('5. Data, state, and interface',level=1)
para('The application keeps request data in memory for the active Streamlit session. Each history entry contains the prompt, optional instructions, a local timestamp, and serialized result fields. No application database or export feature is implemented in the current source. This reduces operational complexity but means session history is not a durable audit trail.')
table(['DATA','LIFETIME / LOCATION','IMPLICATION'],[
('Prompt and instructions','Sent to every selected provider; retained in session history','May contain sensitive content; provider terms and retention controls apply.'),
('API key fields','Streamlit widget/session input or environment/secret source','Not written to a project file by this code; deployment secrets still need protection.'),
('Model output and error','Result in session state, shown in browser','May include sensitive data or provider diagnostics.'),
('Model and endpoint configuration','Source defaults and per-session UI fields','Not a centrally managed deployment configuration.')],[1.6,2.65,2.85])
para('The UI is responsive by use of Streamlit columns and supports up to four visible columns per row; additional selected providers wrap into subsequent rows. It currently emphasizes the newest result set, while earlier prompt summaries appear in a compact expander.')

doc.add_heading('6. Security, privacy, and reliability review',level=1)
table(['AREA','CURRENT STATE','ENGINEERING ACTION'],[
('Credential handling','Password widgets; environment and Streamlit secrets can prefill values.','For hosted use, rely on managed secrets; avoid shared-user key entry and redact provider errors.'),
('Prompt privacy','Prompt is sent to each selected provider.','Show destinations before submit; define data policy and warn on external processing.'),
('Authentication','No login or user authorization layer in app source.','Put behind authenticated access before exposing beyond a trusted local machine.'),
('Request limits','Fixed 180-second timeout; no retry or rate limiting.','Add bounded retries for transient errors, per-provider deadlines, and concurrency quotas.'),
('Input controls','Basic non-empty validation; user controls model and compatible endpoint.','Validate endpoint scheme/host, cap prompt size, and restrict arbitrary remote URLs if deployed.'),
('Observability','Provider, model, and elapsed time appear in UI.','Add structured redacted logs, request IDs, outcome metrics, and usage/token accounting.'),
('Availability','A failed call becomes an error Result; no streaming or cancellation.','Add partial-progress rendering, cancel controls, and explicit retry for failed cards.'),
('Dependency posture','Small dependency set in requirements.txt.','Pin tested versions and scan/update dependencies through a release process.')],[1.15,2.65,3.3])
callout('SECURITY BOUNDARY','This application is suitable as a local prototype with trusted users. It is not yet a hardened multi-user service: Streamlit deployment controls, authentication, endpoint restrictions, abuse limits, and operational secret management must be supplied or implemented before public exposure.', 'FFF4E8')

doc.add_heading('7. Installation and operation',level=1)
para('The bundled README specifies Python 3.10 or later and the following PowerShell workflow from the application folder:')
for s in ['python -m venv .venv',' .\\.venv\\Scripts\\Activate.ps1','pip install -r requirements.txt','streamlit run app.py']:
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(.25); p.paragraph_format.space_after=Pt(2)
    r=p.add_run(s.strip()); r.font.name='Consolas'; r.font.size=Pt(9); r.font.color.rgb=RGBColor.from_string(BLUE)
para('After launch, select one or more providers in the sidebar, enter model names and credentials as required, provide a prompt, and submit. For Ollama, start the local Ollama service and ensure the selected model is already available to that service. Cloud provider calls may incur charges.')
doc.add_heading('Configuration checklist',level=2)
bullet('Use .env.example as a reference; it is not loaded automatically by the app. Define environment variables in the shell or use Streamlit secrets.')
bullet('Do not commit populated secrets files or API keys.')
bullet('For the compatible provider, configure a base URL and a compatible model name.')
bullet('Confirm network access and provider account permissions before sending prompts.')

doc.add_heading('8. Verification status and limitations',level=1)
para('This report is based on source inspection and project documentation. No app launch, provider request, dependency installation, automated test, or visual UI verification was performed for this report. Therefore, endpoint success, model availability, behavior under throttling, cross-provider schema edge cases, and deployed security configuration remain unverified.')
para('The main functional limitations visible in the code are: no streaming; no retry/backoff; no persistent database; no conversation threading beyond repeated one-shot prompts; no response scoring or merge; no token/cost estimates; no file or image input; no response copy/export control; and no cancellation once a submitted request is running.')
doc.add_heading('9. Recommended enhancement roadmap',level=1)
table(['PHASE','ENHANCEMENT','VALUE / ACCEPTANCE OUTCOME'],[
('1 · Correctness','Send Gemini system text through its system instruction field; normalize provider errors; validate JSON shape.','Instructions behave consistently; malformed/empty provider replies produce clear card-level errors.'),
('2 · Resilience','Add per-provider timeout, bounded retry/backoff for retryable statuses, and partial completion updates.','A slow or failing provider does not hide completed answers; retries do not duplicate unbounded charges.'),
('3 · Comparison UX','Add copy/export to Markdown, response collapse, side-by-side scroll, and model configuration presets.','Users can reuse and share a comparison without losing provider/model attribution.'),
('4 · Cost and evaluation','Capture usage metadata where provided; optional rubric-based scoring and human ratings.','Show measured usage when available and keep machine-generated scoring separate from raw responses.'),
('5 · Deployment readiness','Add auth, endpoint allow-listing, rate limits, audit-safe logging, and managed secret injection.','A documented deployment can serve authorized users with bounded abuse and controlled data flow.'),
('6 · Quality assurance','Add unit tests for each response parser and validation path; mocked HTTP integration tests; manual smoke test.','Provider formats, failures, timeout behavior, and core UI flow have repeatable evidence.')],[1.0,2.65,3.45])
doc.add_heading('10. Conclusion',level=1)
para('Parallel establishes a useful foundation for multi-provider answer comparison: a clear single-prompt workflow, independent provider adapters, parallel dispatch, and result cards with timing. The code is intentionally lean and suitable for local experimentation. The most important next changes are correcting Gemini instruction semantics, strengthening validation and error handling, and defining a secure deployment boundary. With those changes and a repeatable verification suite, the prototype can mature into a dependable evaluation workspace.')

doc.add_heading('Appendix A. Project files',level=1)
table(['FILE','PURPOSE'],[
('app.py','Streamlit interface, provider definitions, HTTP adapters, concurrency, result history.'),
('requirements.txt','Runtime dependencies: Streamlit and Requests.'),
('.env.example','Names of environment settings for provider keys and service URLs.'),
('README.md','Local setup, supported provider list, configuration notes, and operating caveats.')],[1.8,5.3])
doc.add_heading('Appendix B. Glossary',level=1)
table(['TERM','MEANING'],[
('Adapter','Provider-specific code that converts a shared request into a provider API call and extracts its response.'),
('OpenAI-compatible API','An endpoint that accepts a Chat Completions-shaped request and returns a compatible response.'),
('Session state','Per-session in-memory Streamlit values that survive reruns while a browser session remains active.'),
('Fan-out','Dispatching a single input to several independent destinations.'),
('Latency','Elapsed time measured around an individual provider request in this app.')],[1.7,5.4])

doc.core_properties.title='Multi-LLM Chat Comparison Application — Technical Project Report'
doc.core_properties.subject='Architecture, implementation review, security assessment, and enhancement roadmap'
doc.core_properties.author='OpenAI'
doc.save(OUT)
print(OUT)
