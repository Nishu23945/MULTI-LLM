from __future__ import annotations

import concurrent.futures
import json
import os
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import requests
import streamlit as st


st.set_page_config(page_title="Parallel — Multi‑LLM Chat", page_icon="✳", layout="wide")

PROVIDERS: dict[str, dict[str, str]] = {
    "OpenAI": {"model": "gpt-4o-mini", "env": "OPENAI_API_KEY", "kind": "openai"},
    "Anthropic": {"model": "claude-3-5-haiku-latest", "env": "ANTHROPIC_API_KEY", "kind": "anthropic"},
    "Google Gemini": {"model": "gemini-2.0-flash", "env": "GEMINI_API_KEY", "kind": "gemini"},
    "Ollama (local)": {"model": "llama3.2", "env": "OLLAMA_BASE_URL", "kind": "ollama"},
    "OpenAI-compatible": {"model": "", "env": "OPENAI_COMPATIBLE_API_KEY", "kind": "compatible"},
}


@dataclass
class Result:
    provider: str
    model: str
    text: str = ""
    error: str = ""
    elapsed: float = 0.0


def post_json(url: str, headers: dict[str, str], body: dict[str, Any], timeout: int = 180) -> dict[str, Any]:
    response = requests.post(url, headers=headers, json=body, timeout=timeout)
    if not response.ok:
        try:
            detail = response.json().get("error", {}).get("message") or response.text
        except (ValueError, AttributeError):
            detail = response.text
        raise RuntimeError(f"HTTP {response.status_code}: {str(detail)[:700]}")
    return response.json()


def ask(provider: str, model: str, prompt: str, system: str, api_key: str, base_url: str) -> Result:
    started = time.perf_counter()
    kind = PROVIDERS[provider]["kind"]
    try:
        if kind in ("openai", "compatible"):
            root = (base_url or "https://api.openai.com/v1").rstrip("/")
            if root.endswith("/chat/completions"):
                url = root
            else:
                url = root + "/chat/completions"
            data = post_json(url, {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}, {
                "model": model, "messages": ([{"role": "system", "content": system}] if system.strip() else []) + [{"role": "user", "content": prompt}], "stream": False,
            })
            text = data["choices"][0]["message"].get("content", "")
            if isinstance(text, list):
                text = "\n".join(part.get("text", "") for part in text if isinstance(part, dict))
        elif kind == "anthropic":
            messages = post_json("https://api.anthropic.com/v1/messages", {
                "x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json",
            }, {"model": model, "max_tokens": 2048, "system": system, "messages": [{"role": "user", "content": prompt}]})
            text = "\n".join(block.get("text", "") for block in messages.get("content", []) if block.get("type") == "text")
        elif kind == "gemini":
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
            contents = ([{"role": "user", "parts": [{"text": system}]}] if system.strip() else []) + [{"role": "user", "parts": [{"text": prompt}]}]
            data = post_json(url, {"Content-Type": "application/json"}, {"contents": contents, "generationConfig": {"maxOutputTokens": 2048}})
            text = "\n".join(part.get("text", "") for part in data.get("candidates", [{}])[0].get("content", {}).get("parts", []))
        else:
            root = (base_url or "http://localhost:11434").rstrip("/")
            data = post_json(root + "/api/chat", {"Content-Type": "application/json"}, {
                "model": model, "messages": ([{"role": "system", "content": system}] if system.strip() else []) + [{"role": "user", "content": prompt}], "stream": False,
            })
            text = data.get("message", {}).get("content", "")
        return Result(provider, model, str(text).strip(), elapsed=time.perf_counter() - started)
    except Exception as exc:  # show errors in their own result card
        return Result(provider, model, error=str(exc), elapsed=time.perf_counter() - started)


def env_value(name: str) -> str:
    try:
        return str(st.secrets.get(name, os.getenv(name, "")))
    except Exception:
        return os.getenv(name, "")


st.markdown("""<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600;700&display=swap');
html,body,[class*="css"]{font-family:'DM Sans',sans-serif} .block-container{padding-top:2.2rem;max-width:1500px}
.brand{font-size:13px;letter-spacing:.16em;text-transform:uppercase;color:#727989;font-weight:700}
.hero{font-size:clamp(36px,5vw,58px);letter-spacing:-.055em;line-height:1.02;font-weight:700;margin:.35rem 0 .8rem;color:#171922}
.sub{color:#777d8c;font-size:15px;margin-bottom:1.5rem}.model-tag{font-family:'DM Mono',monospace;font-size:11px;color:#818797}
.answer-card{border:1px solid #e6e8ed;border-radius:14px;padding:18px 19px;min-height:190px;background:#fff}
.answer-head{display:flex;justify-content:space-between;align-items:center;padding-bottom:12px;margin-bottom:12px;border-bottom:1px solid #eef0f3;font-weight:700}
.stButton>button{border-radius:10px;font-weight:600}.stTextArea textarea{border-radius:12px}
</style>""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## ✳ Parallel")
    st.caption("One prompt. Multiple perspectives.")
    st.divider()
    st.markdown("### Models")
    selected = st.multiselect("Choose providers", list(PROVIDERS), default=["OpenAI", "Anthropic"], label_visibility="collapsed")
    configs: dict[str, dict[str, str]] = {}
    for provider in selected:
        spec = PROVIDERS[provider]
        with st.expander(provider, expanded=True):
            default_model = spec["model"]
            model = st.text_input("Model", value=default_model, key=f"model-{provider}", placeholder="Enter model name")
            if spec["kind"] == "ollama":
                default_key = env_value("OLLAMA_BASE_URL") or "http://localhost:11434"
                base = st.text_input("Ollama URL", value=default_key, key=f"url-{provider}")
                key = ""
            elif spec["kind"] == "compatible":
                base = st.text_input("API base URL", value=env_value("OPENAI_COMPATIBLE_BASE_URL"), key=f"url-{provider}", placeholder="https://your-endpoint/v1")
                key = st.text_input("API key", value=env_value(spec["env"]), type="password", key=f"key-{provider}")
            else:
                base = ""
                key = st.text_input("API key", value=env_value(spec["env"]), type="password", key=f"key-{provider}")
            configs[provider] = {"model": model.strip(), "key": key.strip(), "base": base.strip()}
    st.divider()
    st.caption("Keys stay in this browser session. Environment variables or Streamlit secrets can prefill them.")

st.markdown('<div class="brand">✳ Parallel · Multi‑LLM workspace</div>', unsafe_allow_html=True)
st.markdown('<div class="hero">Think from<br>more than one angle.</div>', unsafe_allow_html=True)
st.markdown('<div class="sub">Send the same prompt to several models at once. Compare their answers side by side.</div>', unsafe_allow_html=True)

if "history" not in st.session_state:
    st.session_state.history = []
with st.form("prompt-form", clear_on_submit=False):
    system_prompt = st.text_input("Instructions (optional)", placeholder="e.g. Be concise, cite assumptions, use plain language")
    prompt = st.text_area("Your prompt", height=140, placeholder="What would you like the models to answer?", label_visibility="collapsed")
    left, right = st.columns([1, 5])
    with left:
        submitted = st.form_submit_button("↗  Ask models", type="primary", use_container_width=True)
    with right:
        st.caption(f"{len(selected)} model{'s' if len(selected) != 1 else ''} selected · requests run in parallel")

if submitted:
    if not prompt.strip():
        st.warning("Enter a prompt first.")
    elif not selected:
        st.warning("Choose at least one model in the sidebar.")
    elif any(not configs[p]["model"] for p in selected):
        st.warning("Add a model name for each selected provider.")
    elif any(PROVIDERS[p]["kind"] != "ollama" and not configs[p]["key"] for p in selected):
        st.warning("Add an API key for each selected cloud provider. Ollama runs locally and does not need a key.")
    elif any(PROVIDERS[p]["kind"] == "compatible" and not configs[p]["base"] for p in selected):
        st.warning("Add the API base URL for the OpenAI-compatible provider.")
    else:
        with st.spinner(f"Asking {len(selected)} model{'s' if len(selected) != 1 else ''} in parallel…"):
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(selected)) as pool:
                futures = [pool.submit(ask, p, configs[p]["model"], prompt.strip(), system_prompt.strip(), configs[p]["key"], configs[p]["base"]) for p in selected]
                results = [future.result() for future in futures]
        entry = {"prompt": prompt.strip(), "system": system_prompt.strip(), "time": datetime.now().isoformat(timespec="seconds"), "results": [r.__dict__ for r in results]}
        st.session_state.history.insert(0, entry)

if st.session_state.history:
    entry = st.session_state.history[0]
    st.markdown("### Answers")
    st.caption(f"Prompt · {entry['time']}")
    st.info(entry["prompt"])
    cols = st.columns(min(len(entry["results"]), 4))
    for index, item in enumerate(entry["results"]):
        with cols[index % len(cols)]:
            st.markdown(f"**{item['provider']}**  \n<span class='model-tag'>{item['model']} · {item['elapsed']:.1f}s</span>", unsafe_allow_html=True)
            if item["error"]:
                st.error(item["error"])
            else:
                st.markdown(item["text"] or "_No text returned._")
    if len(st.session_state.history) > 1:
        with st.expander(f"Previous prompts ({len(st.session_state.history) - 1})"):
            for old in st.session_state.history[1:]:
                st.markdown(f"**{old['time']}** — {old['prompt']}")
                st.caption(" · ".join(f"{r['provider']}: {r['text'][:120]}" for r in old["results"]))
else:
    st.markdown("### Your answer panels will appear here")
    st.caption("Pick providers in the sidebar, enter a prompt, and compare the responses.")

st.divider()
st.caption("Parallel sends prompts to the selected providers. Check each provider’s terms and API pricing before use.")
