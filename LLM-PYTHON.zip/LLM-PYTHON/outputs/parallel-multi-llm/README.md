# Parallel — Multi-LLM Chat

A local Python app that sends one prompt to multiple language models concurrently and displays their answers side by side.

## Run locally

Requires Python 3.10 or later.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL Streamlit prints. Choose providers in the sidebar, enter the model names and API keys, then submit a prompt. Requests run in parallel.

## Providers

- OpenAI (Chat Completions API)
- Anthropic (Messages API)
- Google Gemini (generateContent API)
- Ollama (local server; defaults to `http://localhost:11434`)
- Any OpenAI-compatible chat completions endpoint

Set cloud keys in the sidebar or as environment variables listed in `.env.example`. For Streamlit secrets, create `.streamlit/secrets.toml` with entries such as `OPENAI_API_KEY = "..."`. Do not commit keys. The OpenAI-compatible provider also needs its base URL in the sidebar or `OPENAI_COMPATIBLE_BASE_URL`.

## Notes

- The app does not store API keys on disk. Streamlit session state holds prompt history until the browser session ends.
- Cloud provider requests use their respective hosted APIs and may incur charges. Ollama requests stay on the configured local server.
- This is a direct-answer comparison tool; responses are independent and are not automatically fact-checked against one another.
